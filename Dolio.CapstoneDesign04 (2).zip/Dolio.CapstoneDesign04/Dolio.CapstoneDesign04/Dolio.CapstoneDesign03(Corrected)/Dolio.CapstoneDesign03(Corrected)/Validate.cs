﻿using System;

namespace Dolio.Capstone
{
    public class Validate
    {
        public bool checkifvalid(string s)
        {
            if (checkforfractions(s))
                s = fractiontodecimal(s);

            if (checkfornegatives(s) == false)
                return false;

            if (checkforbillion(s) == false)
                return false;

            if (checkforspecialcharacters(s) == false)
                return false;

            return true;
        }

        public bool checkForTwoDecimals(string s)
        {
            if (s.Length != 2)
                return false;
            return true;
        }

        private bool checkforfractions(string s)
        {
            for (int n = 0; n < s.Length; n++)
            {
                if (s[n] == '/')
                {
                    return true;
                }
            }
            return false;
        }

        private string fractiontodecimal(string s)
        {
            int num;
            int place = 0;
            String denominator = "";
            String numerator = "";
            int denominatorint;
            int numeratorint;

            for (int n = 0; n <= s.Length; n++)
            {
                while (s[n] != '/')
                {
                    numerator += (s[n]);
                    place = n;
                }
            }

            for (int n = 0; n <= s.Length; n++)
            {

                denominator += s[place];

            }

            denominatorint = Convert.ToInt32(denominator);
            numeratorint = Convert.ToInt32(denominator);

            num = numeratorint / denominatorint;

            string dec;

            dec = Convert.ToString(num);

            return dec;
        }

        public bool checkfornegatives(string s)
        {
            for (int n = 0; n < s.Length; n++)
            {
                if (s[n] == '-')
                    return false;
            }

            return true;
        }

        public bool checkforbillion(string s)
        {
            int decimalplaces = s.Length;

            for (int n = 0; n < s.Length; n++)
            {
                if (s[n] == '.')
                    decimalplaces -= 3;
            }

            if (decimalplaces >= 10)
                return false;

            return true;
        }

        public bool checkforspecialcharacters(string s)
        {
            for (int n = 0; n < s.Length; n++)
            {
                if (s[n] != '.' && (s[n] < 48 || s[n] > 57))
                    return false;
            }

            return true;
        }

    }
}
