﻿using System;
namespace Dolio.Capstone
{
    public class Conversion
    {
        Validate v = new Validate();
        Form1 form;

        private String theWords = "";

        public Conversion()
        {
            //splitdecimals(s);
            //send to form UI output
        }

        public String getTheWords()
        {
            return theWords;
        }

        public bool checkfordecimal(String s)
        {
            if (s.Contains('.'))
            {
                return true;
            }

            return false;
        }

        public void splitdecimals(String s)
        {
            String frhalf = "";
            String bchalf = "";
            int place = 0;

            bool dec = checkfordecimal(s);
            if (dec)
            {
                for (int n = 0; n < s.Length; n++)
                {
                    if (s[n] != '.')
                    {
                        frhalf += (s[n]);
                        place = n;
                    }
                }

                for (int n = 0; n < s.Length; n++)
                {

                    bchalf += s[place];

                }
            }
            frhalf = s;

            int digits = getnumberofdigits(frhalf);
            String dollars;
            dollars = converttowords(frhalf, digits, true);
            String cents = ".00";       
            
            if (bchalf.Length > 0)
            {
                if (v.checkForTwoDecimals(bchalf) == false)
                    form.error.Visible = true;
                cents = converttowords(bchalf, digits);
            }
               

            String output;
            output = dollars + " dollars and " + cents + " cents";

            theWords = output;
        }

        public string converttowords(String s, int digits, bool dollars)
        {
            String words = "";
            char p;
            char v;
            int x;
            int next = 0;
            int digitCountDown = digits;

            if (digits == 1)
            {
                v = s[0];
                x = int.Parse(v.ToString());

                words = wordlist(x, 1, 0, 1);
            }
            for (int n = 0; n < digits - 1; n++)
            {                     
                v = s[n];
                x = int.Parse(v.ToString());

                if (digitCountDown > 1)
                {
                    p = s[n + 1];
                    next = int.Parse(p.ToString());
                }                  

                words += wordlist(x, digitCountDown, next, digits) + " ";
                digitCountDown--;
            } 

            return words;
        }

        public string converttowords(String s, int digits)
        {
            String words = "";
            int next;
            int x;      

            x = s[0];
            next = s[1];

            words += wordlist(x, 2, next, digits);

            return words;
        }

        private string wordlist(int x, int digitCountDown, int next, int digits)
        {
            string[] ones = { "", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
            string[] teens = { "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "ninteen" };
            string[] tens = { "", "ten", "twenty", "thirty", "fourty", "fifty", "sixty", "seventy", "eighty", "ninty" };
            string word = "";

            switch (digitCountDown)
            {
                case 0:
                    break;
                case 1:
                    if (digits != 1)
                        break;
                    word = ones[x];
                    break;

                case 2:
                    if (x == 1)
                    {
                        word = teens[next];
                    }
                    else word = tens[x] + ones[next];
                    break;

                case 3:
                    word = ones[x] + " hundred";
                    break;

                case 4:
                    if (digits != 4)
                        break;
                    word = ones[x] + " thousand";
                    break;

                case 5:
                    if (x == 1)
                    {
                        word = teens[next] + " thousand";
                    }
                    else word = tens[x] + ones[next] + " thousand";
                    break;

                case 6:                    
                    word = ones[x] + " hundred";

                    break;

                case 7:
                    if (digits != 7)
                        break;
                    word = ones[x] + " million";
                    break;

                case 8:
                    if (x == 1)
                    {
                        word = teens[next] + " million";
                    }
                    else word = tens[x] + ones[next] + " million";
                    break;
                case 9:
                    word = ones[x] + " hundred";
                    break;
            }
            return word;
        }

        

        public int getnumberofdigits(String s)
        {
            int digits = s.Length;
            return digits;
        }

    }
}
