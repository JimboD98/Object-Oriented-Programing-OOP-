﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dolio.Capstone
{
    public partial class Form1 : Form
    {
        Form1 form;
        Validate valid = new Validate();

        Conversion convert = new Conversion();

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void cvt_Click(object sender, EventArgs e)
        {

            submit();

        }

        private void submit()
        {
            String a = Input.Text;
            bool validate = valid.checkifvalid(a);
            if (validate == false)
            {
                Input.Text = string.Empty;
                error.Visible = true;
            }
            else
            {
                error.Visible = false;
                convert.splitdecimals(Input.Text);
                Output.Text = convert.getTheWords();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

