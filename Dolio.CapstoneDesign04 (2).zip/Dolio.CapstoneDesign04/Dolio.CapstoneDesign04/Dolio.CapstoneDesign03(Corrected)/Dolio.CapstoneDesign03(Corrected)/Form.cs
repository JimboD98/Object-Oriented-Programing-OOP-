﻿using System;
namespace Dolio.Capstone
{
    public class IO
    {
        public IO()
        {
        }

        //private double Btnsubmit_onclick()
        //{
        //    //first the program gets the numbers from the text box and sends it to the validate class
        //    //if it fails validation, an error message appears in a text box. Input is cleared
        //    //if validation passes, input is sent to conversion
        //    //result of conversion is saved as a variable and sent to output
        //}
        private void txtinput_onclick()
        {
            //when you click on the text box it enables data entry
        }

    }
}
